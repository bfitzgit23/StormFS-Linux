#
# 10_file_check_clean_repo.awk
#
# Version 0.1.0 - 2006-08-07
# Johannes Winkelmann, jw at smts dot ch
#
# Tests for invalid files in a clean repo


function list_files(dir,af,   cmd,f)
{
    cmd = "ls -1A --color=none " dir
    delete af
    while (cmd | getline f)
        af[f]
    close(cmd)
}


loglevel_ok(FATAL) && FILENAME ~ PKGFILE && FNR==1 {

    list_files(PORTDIR, af)

    for (f in af) {
        if (f ~ "(.(rar|svn|tar.(bz2|gz|lz|xz|zst)|tgz|tzst|zip)|CVS|REPO|index.html)$")
                perror(FATAL, "invalid file/directory: " f)
    }
}

