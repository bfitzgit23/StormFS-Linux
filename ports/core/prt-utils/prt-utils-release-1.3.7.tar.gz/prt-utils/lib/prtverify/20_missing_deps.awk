#
# 20_missing_deps.awk
#
# Version 0.1 - 2006-08-26
# Juergen Daubert <jue at jue dot li>


loglevel_ok(ERROR) && FILENAME ~ PKGFILE && typeof(DEPENDABLE)=="array" {

    if ( $0 ~ ("^# Depends on:") ) {

        split($0, ac, /:[[:space:]]*/)
        split(ac[2], ad, /[[:space:]]*,[[:space:]]*|[[:space:]]+/)

        for (d in ad) {
            if (ad[d] !~ /^ *$/ && ! (ad[d] in DEPENDABLE))
                perror(ERROR, "missing dependency: " ad[d])
        }
    }
}

