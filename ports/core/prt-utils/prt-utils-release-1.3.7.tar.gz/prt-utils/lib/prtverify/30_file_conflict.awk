#
# 30_file_conflict.awk
#
# Version 0.1.0 - 2006-08-31
# Juergen Daubert <jue at jue dot li>


loglevel_ok(ERROR) && FILENAME ~ FOOTPRINT && typeof(fc_map) == "array" {
    if ($3 in fc_map) {
        split(fc_map[$3], am, ":")
        for (i in am) {
            if (am[i] != COLLPORT)
                perror(ERROR, "file conflict found: " am[i] " -> " $3)
        }
    }
}

