#
# 20_pkgfile_functions.awk
#
# Version 0.1
# John McQuah <jmcquah at disroot dot org>

loglevel_ok(INFO+WARN+ERROR) && FILENAME ~ PKGFILE {

    if ( /^\s*(check_signature|check_md5sum)\(\) / ||
           /^\s*(build_needed|build_package|install_package)\(\) / ) {
	sub(/{.*/,"")
        perror(ERROR, "internal pkgmk function redefined: " $0)
    }

    if ( /^\s*(check_footprint|update_footprint|update_md5sum)\(\) / ||
	 /^\s*(make_signature|refresh_signature)\(\) / ) {
	sub(/{.*/,"")
        perror(WARN, "internal pkgmk function redefined: " $0)
    }

    if ( /^\s*(download_file|download_source|unpack_source)\(\) / ) {
	sub(/{.*/,"")
        perror(INFO, "internal pkgmk function redefined: " $0)
    }

}
