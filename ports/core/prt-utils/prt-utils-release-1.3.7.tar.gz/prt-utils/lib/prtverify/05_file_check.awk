#
# 05_file_check.awk
#
# Version 0.2.0 - 2008-05-21
# Juergen Daubert <jue at jue dot li>
#
# Pre-flight operations needed by the bash wrapper,
#  but inlined for the awk wrapper (which doesn't rely on 
#  writing temporary files to disk, or encapsulating long strings
#  and passing them by value via the -v flag)
# 
# Sets some global variables
# - PORTDIR    the full path of the port
# - COLLPORT   a shortcut for Collection/Port like core/gcc
#
# PF array of mandatory port files was defined in 00_prtverify_lib.awk
# DEP_PORTS, FOOTPRINTDB, WHITE_LIST strings are set by the wrapper script

BEGIN {
   
    PORTDIR = ARGV[1]
    # already tested to be a directory by the wrapper script,
    # so we don't need to duplicate the test here
    # if (system("test -d " PORTDIR) != 0) {
    #    usr_error(PORTDIR " is not a directory, ignoring")
    #    exit
    # }

    PORTDIR = fullpath(PORTDIR)
    COLLPORT = collectionport(PORTDIR)

    delete ARGV
    ARGC  = 1

    for (f in PF) {
        p = PORTDIR "/" f
        if (system("test -f " p) == 0)
            ARGV[ARGC++] = p
        else 
            if(loglevel_ok(FATAL))
                perror(FATAL, "file not found: " f)
    }

    if (ARGC == 1)
        exit

    # moved from 20_missing_deps.awk
    if (DEP_PORTS) {
        split(DEP_PORTS, ac)
        for (i in ac)
            DEPENDABLE[ac[i]]
    }
    
    # moved from 30_file_conflict.awk
    if (FOOTPRINTDB) {
        while ((getline l < FOOTPRINTDB) > 0) {
            split(l, am, "\t")
            fc_map[am[1]] = am[2]
        }
        close(file)
    }

    # read the whitelist (possibly spread over multiple files,
    #   hence the need to split on spaces and create an array)
    if (WHITE_LIST) {
        split(WHITE_LIST,af)

        for (f in af) {
            if (system("test -f " af[f]) != 0) {
                usr_error("Error: file " af[f] " not found!")   
                continue
            }
            while ((getline line < af[f]) > 0)
                WLIST[line]
        }
    }
}

