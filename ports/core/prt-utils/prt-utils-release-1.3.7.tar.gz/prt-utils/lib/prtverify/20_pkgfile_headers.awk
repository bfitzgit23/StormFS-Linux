#
# 20_pkgfile_headers.awk
#
# Version 0.1.2 - 2024-04-14
# John McQuah <jmcquah at disroot dot org>
#
# Version 0.1.1 - 2006-08-24
# Juergen Daubert <jue at jue dot li>


loglevel_ok(ERROR) && FILENAME ~ PKGFILE {

    # with each new file in ARGV, assume fields are empty until proven otherwise
    if (FNR==1) {
        pkgfile_headers["Description"] = 0
        pkgfile_headers["URL"] = 0
        pkgfile_headers["Maintainer"] = 0
	headers_checked = 0
    }
    
    if ($0 ~ /^#[[:space:]]+(Description|URL|Maintainer):/) {
        split($0, ac, ":")
        sub(/^#[[:space:]]+/,"",ac[1])
        pkgfile_headers[ac[1]] = 1
        if (ac[2] ~ /^[[:space:]]*$/)
            perror(ERROR, "empty header found: " ac[1])
    }

    # Once we get to a non-commented line, all mandatory headers should be defined
    if ((! headers_checked) && ($1 !~ /^#/)) {
        for (h in pkgfile_headers) {
            if (pkgfile_headers[h] != 1)
                perror(ERROR, "header not found: " h)
        }
	headers_checked = 1
    }
}
