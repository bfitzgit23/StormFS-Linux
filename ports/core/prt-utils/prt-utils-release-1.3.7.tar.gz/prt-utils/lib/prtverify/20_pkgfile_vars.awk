#
# 20_pkgfile_vars.awk
#
# Versions 0.1.3--0.1.4
# John McQuah <jmcquah at disroot dot org>
#
# Version 0.1.2 - 2006-07-14
# Juergen Daubert <jue at jue dot li>

loglevel_ok(ERROR) && FILENAME ~ PKGFILE {

    # when reading the next port in ARGV, assume 
    # variables are unset until proven otherwise
    if (FNR==1) {
        pkgfile_vars["name"] = 0
        pkgfile_vars["version"] = 0
        pkgfile_vars["release"] = 0
        pkgfile_vars["source"] = 0
        vars_checked = 0

	# define PORT so we can check for agreement with the dirname
        PORT = gensub(/\/Pkgfile$/, "", 1, FILENAME)
        sub(/^.*\//,"",PORT)
    }

    if ( $1 ~ /^\s*(name|version|release|source)=/ ) {
        split($1,av,/=/)
        pkgfile_vars[av[1]] = 1

        # moved here from 20_release_number.awk
        if ( (av[1] == "release") && (av[2] !~ /^[1-9][0-9]*$/) )
            perror(ERROR, "variable release contains invalid characters: " av[2])

        # moved here from 20_port_name_match.awk
        if ( (av[1] == "name") && (av[2] != PORT) )
            perror(ERROR, "Pkgfile defines name not matching the directory name: " av[2])
    }

    if ( $1 ~ /^\s*PKGMK_(SOURCE_MIRRORS|PACKAGE_DIR|COMPRESSION_MODE)=/ ) {
	    split($1,av,/=/)
            perror(ERROR, "Pkgfile redefines a global pkgmk variable: " av[1])
    }

    if ( $1 ~ /^\s*PKGMK_(INSTALL|DOWNLOAD|DOWNLOAD_ONLY|EXTRACT_ONLY)=/ ) {
	    split($1,av,/=/)
            perror(ERROR, "Pkgfile redefines a global pkgmk variable: " av[1])
    }

    if ( $1 ~ /^\s*PKGMK_(UP_TO_DATE|UPDATE_FOOTPRINT|IGNORE_FOOTPRINT|IGNORE_NEW)=/ ) {
	    split($1,av,/=/)
            perror(ERROR, "Pkgfile redefines a global pkgmk variable: " av[1])
    }

    if ( $1 ~ /^\s*PKGMK_(FORCE|KEEP_WORK|UPDATE_MD5SUM|UPDATE_SIGNATURE|PRIVATEKEY)=/ ) {
	    split($1,av,/=/)
            perror(ERROR, "Pkgfile redefines a global pkgmk variable: " av[1])
    }

    if ( $1 ~ /^\s*PKGMK_(IGNORE_MD5SUM|CHECK_MD5SUM|IGNORE_SIGNATURE|CHECK_SIGNATURE)=/ ) {
	    split($1,av,/=/)
            perror(ERROR, "Pkgfile redefines a global pkgmk variable: " av[1])
    }

    if ( $1 ~ /^\s*PKGMK_(UPDATE_MD5SUM|UPDATE_SIGNATURE|REFRESH_SIGNATURE|CLEAN)=/ ) {
	    split($1,av,/=/)
            perror(ERROR, "Pkgfile redefines a global pkgmk variable: " av[1])
    }

    # all these variables should be defined by the time 
    # we encounter the build function
    if ( ($1 ~ /build\(\)/) && (! vars_checked) ) {
        for (v in pkgfile_vars) {
            if (! pkgfile_vars[v])
                perror(ERROR, "variable not found: " v)
        }
        vars_checked = 1
    }
}

