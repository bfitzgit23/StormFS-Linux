#!/usr/bin/env bash
# Find redundant dependencies
# Johannes Winkelmann <jw at tks6 dot net>

# $ cd /usr/ports/contrib
# $ findredundantdeps *
# $ findredundantdeps bmp

usage()
{
    echo "usage: ${0##*/} [-v|-s|-f] <port>" >&2
    exit 1
}

verbose=false
suggest=false
fix=false

while getopts ":vsf" opt; do
    case $opt in
        v) verbose=true ;;
        s) suggest=true ;;
        f) fix=true ;;
        \?) usage ;;
    esac
done
shift $(( OPTIND - 1 ))

case "$(prt-get version | cut -d" " -f2)" in
    5.19.[1-6]) deptree="prt-get deptree" ;;
             *) deptree="prt-get --config-set='softdeps no' deptree" ;;
esac

[ -n "$*" ] || usage

for name in "$@"; do
    mapfile -t direct < <(prt-get info "$name" 2>&1 | \
	    gawk -v FS=: '$1 ~ /Path/ {gsub(/^[[:space:]]*/,"",$2); gsub(/ /,"%23",$2); print $2};
                      $1 ~ /not found/ {print "NotFound"};
		      $1 ~ /Dependencies/ {gsub(/^[[:space:]]*/,"",$2); gsub(/[, ]/,"\n",$2); print $2}')
    [[ ${direct[0]} = "NotFound" ]] && { echo "$name not found in the active ports collections"; continue; }
    PKGFILE="${direct[0]//%23/ }/$name/Pkgfile"
    unset "direct[0]"
    mapfile -t redundant < <(eval $deptree "$name" | \
      gawk '/^...[[:space:]]{3}[a-z].*[^>]$/ {dd[$NF]}
            /^...[[:space:]]{4}.*[^>]$/      {id[$NF]}
            /^...[[:space:]]{3}[a-z].*-->$/ {dd[$(NF-1)]}
            /^...[[:space:]]{4}.*-->$/      {id[$(NF-1)]}
            END{
                for (i in id) { if (i in dd) rd[i] }
                if (typeof(rd)=="array") {
                    for (i in rd) { print i }
                }
            }')

    if [ ${#redundant[@]} -gt 0 ]; then
        echo "Redundant deps for $name are: ${redundant[*]}"
        mapfile -t right < <(comm -23 \
                       <(echo "${direct[*]}" | tr ' ' '\n' | sort) \
		       <(echo "${redundant[*]}" | tr ' ' '\n' | sort))
        if [ "$suggest" = true ]; then
           echo "Right is: # Depends on: ${right[*]}"
        fi
        if [ "$fix" = true ]; then
           sed "s/^#.*Depends on:.*/# Depends on: ${right[*]}/" -i.orig "$PKGFILE"
           echo " * Fixed $name"
        fi
    else
        [ "$verbose" = true ] && echo " * $name is fine."
    fi
done
