#!/usr/bin/env bash
# Find dependency of files in /usr/lib and /usr/bin of a port by looking at
#  the output of ldd
#
# Johannes Winkelmann <jw at tks6 dot net>
# awk stuff by Juergen Daubert <jue at jue dot li>

version=1.9.1
set -eo pipefail
pkgdb="/var/lib/pkg/db"

export LD_LIBRARY_PATH=/lib:/usr/lib:/lib32:/usr/lib32:$LD_LIBRARY_PATH

function printDep() {
    port="$1"
    declare -a deps
    while read -r f; do
        [ -f "/$f" ] || continue
        while read -r d; do
            deps+=("$d")
        done < \
        <(ldd "/$f" 2>/dev/null | awk '!/(linux-gate)|( dynamic)|(not found)/ {print $(NF-1)}')
    done < \
    <(awk -v p="$port" -v RS="" '($1==p) { for (i=2;i<=NF;++i) {if ($i ~ /(sbin|bin|lib|lib32)\//) print $i }}' $pkgdb)

    [ ${#deps[@]} = 0 ] || mapfile -t rdeps < <(realpath ${deps[@]} | sort | uniq)

    for r in "${rdeps[@]}"; do
        awk -v p="$port" -v s="$r" -v RS="" '(($1 != p) && ($0 ~ substr(s,2))) {printf("^%s (.*)\n",$1)}' $pkgdb
    done | sort | uniq
}

[ -n "$1" ] || { echo "Usage: ${0##*/} <port>"; exit 1; }

pkgName="${1##*/}"

prt-get isinst "$pkgName" &> /dev/null || { echo "$pkgName is not installed"; exit 1; }

prt-get printf "%n (%p)\n" \
      | grep -f <(printDep $pkgName) \
      | sed 's,(.*\/,(,' \
      | sort -k 2
