// Copyright (C) 2016 James Buren
//
// This file is part of revdep.
//
// revdep is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// revdep is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with revdep.  If not, see <http://www.gnu.org/licenses/>.

#pragma once

#include "elf.h"
#include "pkg.h"
#include <unordered_map>

typedef std::unordered_map <std::string, Elf *> ElfMap;

class ElfCache {
private:
	ElfMap _data;
	bool findLibraryByDirs(const Elf *elf, const std::string &lib, const StringVector &dirs);
	bool findLibraryByPath(const Elf *elf, const std::string &lib);

public:
	~ElfCache();
	const Elf *LookUp(const std::string &path);
	bool FindLibrary(const Elf *elf, const Package &pkg, const std::string &lib, const StringVector &dirs);
};
