# Introduction

prt-utils is a collection of tools for CRUX, mainly oriented towards
package and port management. prt-utils is available in the opt collection.

## Documentation

Please refer to the manual pages included in the package.

## Included tools

|  Name          |  Author(s)  |  Description  |
|:---------------|:------------|:--------------|
| dllist | Johannes Winkelmann | List files to be downloaded to install a port |
| finddeps | Johannes Winkelmann | Find actual dependencies for a port |
| findredundantdeps | Han Boetes, Johannes Winkelmann | Find unnecessary dependencies of a port |
| oldfiles | Simone Rota | List old sources and packages from centralized dirs |
| pkg\_installed | Han Boetes | Create under /usr/ports/installed a symlink to each installed port |
| pkgexport | Andrew Green | Reconstruct a native CRUX package from the components installed on main or mounted filesystem |
| pkgfoster | Jukka Heino | Clean up orphaned packages, i.e., packages which no other package depends on |
| pkgsize | Damir Saric | Calculate the disk usage of an installed package |
| pkg-not | Jose Beneyto | Report files on disk that are not owned by any installed package |
| portspage | Jukka Heino | Generate html index of a directory containing ports |
| prtcheck | Martin Opel | Ensure that the port directory is complete and the Pkgfile defines essential fields |
| prtcheckmissing | Martin Opel | Check for missing files |
| prtcheckperms | John McQuah | Check for permissions that have diverged from what the maintainer intended |
| prtcreate | Martin Opel | Create a Pkgfile from a template for new ports |
| prtorphan | Martin Opel | Check for orphaned packages or files on your system |
| prtrej | Markus Ackermann, Martin Opel | Interactively go through the list of files that have been rejected by pkgadd, and decide what to do about each one |
| prtsweep | Martin Opel | Remove old files from the ports tree |
| prtverify | J�rgen Daubert | Validate CRUX ports with an extensive set of tests |
| prtwash | Simone Rota | Clean up a ports tree |
| revdep | James Buren | Check for installed packages that are linked to nonexistent libraries |

## Sorted by language

| Language    | Tool(s)    |
|:-----------:|:-----------|
| bash | dllist, pkg\_installed, pkgexport, pkgfoster, pkgsize, pkg-not, prtcheck, prtcreate, prtrej |
| C++ | [revdep](#history-of-rewrites) |
| awk | [finddeps](#history-of-rewrites), [findredundantdeps](#history-of-rewrites), [prtverify](#history-of-rewrites) |
| perl | oldfiles, portspage, prtcheckmissing, prtcheckperms, [prtsweep](#history-of-rewrites), [prtwash](#history-of-rewrites) |

## Sorted by the way they get their information

This table might prove useful if we later make breaking changes to **pkgutils** (specifically
the Pkgfile format and the package database), **prt-get**, or their config files.

| Data source | Tool(s)    |
|:------------|:-----------|
| package database (opened directly by the program itself) | finddeps, oldfiles, pkg-not, prtcheckmissing, prtcheckperms, prtorphan, prtverify, revdep |
| package database (opened by calling pkginfo) | pkgsize |
| signature or footprint parsed in the script itself | oldfiles, prtcheck, prtsweep, prtverify |
| /etc/pkgmk.conf parsed in the script itself | oldfiles |
| /etc/pkgmk.conf passed to a bash subshell for echoing a variable's value | pkgexport, prtreverse |
| /etc/pkgmk.conf grepped to extract a single line defining a variable | dllist |
| Pkgfile parsed in the script (not sourced) | prtverify, portspage |
| Pkgfile [sourced by the script](#sourcing-pkgfile) or a bash subshell | dllist, pkgsize, prtcheck, prtwash |
| /etc/prt-get.conf parsed by the script itself | pkgfoster, prtorphan, oldfiles, prtwash |
| prt-get printf | finddeps, oldfiles, pkg\_installed, prtcheckperms |
| prt-get (other command) | dllist, findredundantdeps, pkgexport, pkgfoster, pkgsize, prtorphan, prtwash, prtverify |

## Sorted by expected environment and argument

(empty field = no restrictions)

| $PWD | Argument | Tool(s) | Historical precedent |
|:----:|:---------|:--------|:--------------------:|
| | the directory of a port collection | portspage | httpup-repgen |
| the directory of a port collection | not required, only toggles the mode | portspage | httpup-repgen |
| the directory of an individual port | not required, only toggles the mode | prtcheck, prtcreate | pkgmk |
| | not required, only toggles the mode | oldfiles, pkgfoster, pkg\_installed, prtrej, prtcheckmissing, prtcheckperms | prt-get listinst |
| | at least one directory | prtverify, pkg-not | none? |
| | either the "automatic mode" option, or at least one directory | prtwash, prtsweep | none? |
| | **one** installed port | pkgexport | pkginfo -l |
| | **one** port in an active collection  | dllist, finddeps, findredundantdeps | prt-get info |
| | **one or more** port names, found in the package database **or** in the active collections | pkgsize | none? |
| | **one or more** port names (must belong to an active collection) | dllist, findredundantdeps | prt-get depinst |

## Footnotes

### Sourcing Pkgfile

The tools that require sourcing the Pkgfile either do so themselves, or spawn another 
bash process to obtain the necessary information. Thus, to implement such a tool in a
language other than bash would insert an extra layer between the user-facing side and the 
side that deals with the ports tree. For now the only tool with such a translation layer 
is prtwash. The most promising candidates for a future rewrite are:

  - dllist
  - pkgsize
  - prtcheck

Open a Gitea pull request if you write a replacement for one of the scripts above and 
want it included in the next version of prt-utils.

### History of rewrites

  - **revdep** was the original name of a shell script by Johannes Winkelmann, which proved so popular that the same name was retained for the C++ rewrite.
  - **prtsweep** and **prtwash** were rewritten in Perl for prt-utils 1.3, incorporating the well-established Perl idioms of oldfiles and prtcheckmissing for parsing the ports drivers and prt-get.conf. Their previous incarnations as bash scripts had grown too unwieldy in the aftermath of pkgmk becoming able to rename downloaded sources, and it was deemed easier to start afresh in a new language.
  - **finddeps** attracted attention beyond the CRUX community thanks to the blog posts of a former Slackware user, who developed a workflow for deploying binary packages that relied heavily on finddeps. As of prt-utils 1.3.2, finddeps no longer uses bash as the interpreter, but instead runs entirely as an awk process. If you prefer the bash version, feel free to create an overlay port that runs `make install-legacy` after the usual `make install`. You might choose to edit the Makefile in your overlay port, omitting from the `install-legacy` target those tools that you do not need in their old bash versions.
  - **findredundantdeps** began as a bash script. In later versions it started relying on awk for so much of its logic that it made sense to rewrite the entire process as an awk program. For users who prefer the old shebang, the bash implementation of findredundantdeps continues to be distributed with the tarball but is not installed by default. Feel free to create an overlay port that runs `make install-legacy` after the usual `make install`, if you want the bash script instead.
  - **prtverify** was originally designed with the user-facing part written in bash and the modules written in awk. Starting with prt-utils 1.3.2, the default prtverify program uses awk as its sole interpreter (with the bash wrapper available via `make install-legacy`).

### Accommodating quirks of the pkgdb

Most of the tools that scan the pkgdb were not designed to handle the fact that entries are added _even for
files that match an INSTALL NO rule in pkgadd.conf_. This situation was not anticipated because the
footprint is supposed to contain the minimal essential set of files required for the functionality of the built package, so writing a pkgadd.conf INSTALL NO rule would almost always result in breakage. But as knowledge of baguette's [libtool-garbage-day script](https://github.com/baguette/crux-ports/blob/master/Util/bin/libtool-garbage-day.sh) began to diffuse throughout the CRUX community, some users started to experiment with INSTALL NO rules. The utilities in this repo would now need to acquire additional logic to handle this situation.
 - **prtcheckmissing** was the first utility to start filtering the list of expected files against the
   pkgadd.conf INSTALL NO rules, made easier by Perl's support for quoted regular expressions.
 - **pkgexport** in prt-utils 1.3.4 acquired the ability to restrict the file list to those patterns not matching an INSTALL NO rule.
 - **prtreverse** (not an installation target since prt-utils 0.6.1) takes its file list from .footprint
   rather than the pkgdb, and hence might attempt to assemble a package from components that were never
actually built (if the user called pkgmk with --ignore-footprint). Despite this drawback, filtering the file list against the pkgadd.conf INSTALL NO rules helps avoid attempts to copy files that were blocked from installation.

### Consistency with httup-repgen

The tools descended from httpup-repgen diverged in the way they chose to 
interpret the first (non-mandatory) argument passed on the command line:

  - as the name of a directory, the same way httpup-repgen does (portspage)
  - as the name of a subdirectory under $PWD (pkg-repgen, prior to pkg-get version 0.5)

Starting with prt-utils 1.3.3, portspage will now treat any subsequent arguments
the same way that pkg-repgen treats its non-mandatory arguments: as the names
of individual ports that should be inserted or overwritten in the 
previously-generated index. This feature lets you apply quick updates to a large
port collection, without needing to recurse through every subdirectory. But 
portspage continues to interpret its **first** argument as the name of a 
directory, in keeping with its intended use as a cgi script on a webserver (where
it might be desired to serve the index from a nearby directory, not the collection 
itself). Starting with pkg-get 0.5, pkg-repgen will adopt a similar convention 
(distinguishing between $ARGV[1] and subsequent arguments), so that users who invoke 
all three tools outside of a scripted update procedure can develop muscle memory
more easily.
