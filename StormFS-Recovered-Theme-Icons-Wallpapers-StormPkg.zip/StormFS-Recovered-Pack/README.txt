StormFS Recovered Theme / Icons / Wallpapers / StormPkg Bundle

Contents:
- StormFS-Theme-Icons-v3.zip  - regenerated StormFS GTK + icon theme, including application/panel/menu assets
- stormd_wallpapers.zip       - StormD/StormFS wallpaper pack recovered from the previous build
- stormfs-pm.tar.gz           - StormPkg / stormfs-pm application package
- stormd_aurorae_restore.zip  - StormD Aurorae window decoration themes
- stormd_kwin_fixed_themes.zip - StormD KWin window decoration themes
- stormd_darkblood_darkcold_assets.zip - DarkBlood/DarkCold theme assets

The StormFS-Theme-Icons-v3 archive is the latest uploaded theme/icon set available in this session.
